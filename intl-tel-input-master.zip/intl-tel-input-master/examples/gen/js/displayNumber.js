var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1590403638580" // just for formatting/placeholders etc
});
